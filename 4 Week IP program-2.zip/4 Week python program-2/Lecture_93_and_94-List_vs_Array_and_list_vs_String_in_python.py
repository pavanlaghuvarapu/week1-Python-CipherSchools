#strings are immutable (cant change)
    #cannot add characters
#lists are mutable (can be changed)
    #can add characters
s="string"
t=s.title()
print(t)


l=['word','word1','word2']
l.pop(2)
print(l)
l.append('word3')
print(l)