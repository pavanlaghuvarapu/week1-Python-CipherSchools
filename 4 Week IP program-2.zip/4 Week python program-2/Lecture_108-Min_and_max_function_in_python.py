num = [1,45,676]
print(min(num))
print(max(num))

def greatest_difference(l):
    return max(l)-min(l)

print(greatest_difference(num))