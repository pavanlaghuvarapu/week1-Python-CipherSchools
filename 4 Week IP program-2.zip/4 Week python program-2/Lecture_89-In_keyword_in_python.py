fruits1=["Mango","Grapes","apple","chiku"]
if 'apple' in fruits1:
    print("apple is present")
else:
    print("not present")