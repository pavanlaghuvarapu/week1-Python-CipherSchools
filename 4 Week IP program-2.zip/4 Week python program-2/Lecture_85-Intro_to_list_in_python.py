numbers=[1,2,3,4]
print(numbers)
words=["word1","word2","word3"]
print(words)
mixed=[1,2,3,4,"five","six",None]
print(mixed)
mixed[1:] = ['three','four']
print(mixed)