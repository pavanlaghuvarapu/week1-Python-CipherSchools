fruits = ['oranges','apple']
fruits.insert(1,"grapes")
print(fruits)

fruits1=["Mango","Grapes"]
print(fruits.extend(fruits1))
print(fruits.append(fruits1))
print(fruits+fruits1)