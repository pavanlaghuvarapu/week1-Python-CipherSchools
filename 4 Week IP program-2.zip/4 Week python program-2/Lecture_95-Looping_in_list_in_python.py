fruits1=["Mango","Grapes","apple","chiku","banana","kiwi","pear"]
#for loop
for fruit in fruits1:
    print(fruit)
#while loop
i = 0 # kyunki list ki pehli item ki jo position hai vo zero hai
while i<len(fruits1):
    print(fruits1[i])
    i+=1