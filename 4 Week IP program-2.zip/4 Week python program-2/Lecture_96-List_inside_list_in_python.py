matrix=[[1,2,3], [4,5,6], [7,8,9]] #2D list
#3 items in list
print(matrix[0])
for i in matrix:
    print(i)
#print elemets of list separately
for sublist in matrix:
    #sublist me 1, 2 , 3 store hoga and further
    for i in sublist:
        print(i)

print(matrix[1][1])

s="string"
print(type(s))
print(type(matrix))