fruits = ['grapes','apple']
fruits.append('mango')
print(fruits)

fruits=[]
fruits.append('mango')
fruits.append("apple")
print(fruits)