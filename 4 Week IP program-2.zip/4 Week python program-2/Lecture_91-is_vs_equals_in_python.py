fruits1=["Mango","Grapes","apple","chiku"]
fruits3=["Mango","Grapes","apple","chiku","banana","kiwi","pear"]
fruits2=["Mango","Grapes","apple","chiku"]
print(fruits1==fruits2) #values are same
print(fruits1 is fruits3) # false because it checks th location where the variable is stored if it is same then the result is true