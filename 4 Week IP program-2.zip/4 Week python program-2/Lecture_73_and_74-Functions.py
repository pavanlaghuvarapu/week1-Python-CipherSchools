def add_two(a,b):
    return a+b

total=add_two(1000,4)
print(total)
a=input("Enter a string:")
b=input("Enter a string 2: ")
print(add_two(a,b))

#LEcture 74 - Return v/s print
def add_three(a,b,c):
    print(a+b+c)

add_three(5,5,5)