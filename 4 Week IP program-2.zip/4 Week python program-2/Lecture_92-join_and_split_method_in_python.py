user_info = 'Sandarbh 18'.split()
print(user_info)
user_info =['Sandarbh', '18']
print(','.join(user_info))