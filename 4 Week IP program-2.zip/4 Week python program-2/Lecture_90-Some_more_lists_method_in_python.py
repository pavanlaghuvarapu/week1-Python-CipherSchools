fruits1=["Mango","Grapes","apple","chiku","banana","kiwi","pear"]
print(fruits1.count("apple"))


print(sorted(fruits1))


numbers=[1,9,3,7,5,0]
print(sorted(numbers))

numbers_copy=numbers.copy
print(numbers_copy)