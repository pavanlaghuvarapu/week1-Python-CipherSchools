total=0
for i in range(1,11):
    total+=i
print(total)

n = int(input("enter the number: "))
total = 0
for i in range(1,n+1):
    total+=i
print(total)