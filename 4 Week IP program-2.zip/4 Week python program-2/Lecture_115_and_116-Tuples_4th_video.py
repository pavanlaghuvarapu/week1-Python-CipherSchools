nums = tuple(range(1,11))
print(nums)
#changing tuple to list
nums = list((1, 2, 3, 4, 5, 6, 7, 8, 9, 10))
print(type(nums))
#changing tuple to string
nums = str((1, 2, 3, 4, 5, 6, 7, 8, 9, 10))
print(type(nums))
print(nums)