user_info={'name':'sandarbh','age':'18'}
print(user_info.get('names',' not found ! '))
# none ki jagah not found aayega agar names lika tou kyunki vo hamari dict. me keyword hai hi nhi